import './App.css';

//Components
import Product from '../product/product';
import WishList from '../wishlist/wishlist';

// services
import HttpService from '../services/http-services';


import React, { Component } from 'react';



const http  = new HttpService();

class App extends Component {
  constructor(props) {
    super(props);
     
    this.state  = {products:[]};

    this.loadData = this.loadData.bind(this);
    
  }

  componentDidMount(){
    this.loadData();
  }


   loadData = ()  => {
     var self = this;
    http.getProducts().then(data => {
    
      self.setState({products: data})
    }, err => {

    });

   }
productList = ()  =>  {
  const list  = this.state.products.map((product) =>  
    <div className="col-sm-3" key={product._id}>
      <Product product={product} />
    </div>
  );
  return(list);
}

render() {
  return (
<div className="App">
  <div className="App-header">
    <h1>Welcome to CocoLand </h1>
  </div>
  <div className="container-fluid App-main">
    <div className="row">
      <div className="col-sm-8">
        <div className="row">
        {this.productList()}
        </div>
      
      </div>
      <div className="col-sm-4">
        <WishList />
      </div>
    
  {/* <Product className="col-sm-4" price="10" title="Dairy Milk" imgUrl="https://fabawards.com/wp-content/uploads/FAB14_Cadbury-Dairy-Milk-a.jpg" />
        <Product className="col-sm-4" price="10" title="Dairy Milk" imgUrl="https://fabawards.com/wp-content/uploads/FAB14_Cadbury-Dairy-Milk-a.jpg" />
        <Product className="col-sm-4" price="10" title="Dairy Milk" imgUrl="https://fabawards.com/wp-content/uploads/FAB14_Cadbury-Dairy-Milk-a.jpg" /> */}
        </div>
  </div>
</div>

  );
}
}
export default App;



//     <div className="App">
//       <div className="App-header">
//       {/* <img src={logo} classname="App-logo" alt="logo" /> */}

//       </div>    
//        <h1>Hello world</h1>
//        <h2> Welcome to React Project </h2>
// </div>

//        <div className="container App-main">
//          <div className="row">

         
//         <Product className="col-sm-4" price="10" title="Dairy Milk" imgUrl="https://fabawards.com/wp-content/uploads/FAB14_Cadbury-Dairy-Milk-a.jpg" />
//         <Product className="col-sm-4" price="10" title="Dairy Milk" imgUrl="https://fabawards.com/wp-content/uploads/FAB14_Cadbury-Dairy-Milk-a.jpg" />
//         <Product className="col-sm-4" price="10" title="Dairy Milk" imgUrl="https://fabawards.com/wp-content/uploads/FAB14_Cadbury-Dairy-Milk-a.jpg" />
//         </div>

//     </div>
   


//   );
// }
// }
