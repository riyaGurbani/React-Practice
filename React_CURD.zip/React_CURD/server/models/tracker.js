const mongoose  =   require('mongoose');

const trackerSchema =   new mongoose.Schema({
    no_of_hours:    {
        type:   Number,
        required:   true,
    },
    days_cycle: {
        type:   Number,
        required:   false,
    },
}); 

const tracker   =   mongoose.model("trackData", trackerSchema)
module.exports  =   tracker