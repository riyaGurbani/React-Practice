const express   =   require("express");
const mongoose  =   require("mongoose");
const cors  =   require("cors");
const app   =   express();


const TrackModel    =   require("./models/tracker");

app.use(express.json());
app.use(cors());
mongoose.connect("mongodb+srv://newuser:newuser@crud.xkqsx.mongodb.net/tracker?retryWrites=true&w=majority", {
        useNewUrlParser: true,

});

app.post("/insert",    async   (req,res)   =>  {
     const track =   req.body.track;
     const days  =   req.body.days;
    const Track =   new TrackModel({no_of_hours: track ,days_cycle: days});
    try {
        await   Track.save();
        res.send("Data Inserted");

    }
    catch(err)  {
        console.log(err)
    }
});

app.get("/read",    async   (req,res)   =>  {
   TrackModel.find({},  (err,   result) =>  {
       console.log('ERROR', err)
       if(err)  {
           res.send(err);
       }
       res.send(result);
   });
});

app.put("/update",    async(req,res)   =>  {
    const newTrackName =   req.body.newTrackName;
    const id  =   req.body.id;
    console.log('UPDTATE!!!')
   try {
    await  TrackModel.findById(id, (err, updatedTrack)    =>  {
          updatedTrack.no_of_hours = newTrackName;
          updatedTrack.save();
          res.send("update");
      });

   }
   catch(err)  {
       console.log(err)
   }
});

app.delete("/delete/:id",   async   (req,res)   =>  {
    const   id =    req.params.id;
    console.log(id);
    await TrackModel.findByIdAndRemove(id).exec();
    res.send("Deleted");
});

app.listen(5000,    ()  =>  {
    console.log("Server running on port 5000");
});
