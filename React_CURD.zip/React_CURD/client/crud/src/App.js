import React, { useState, useEffect} from 'react';
import Axios from 'axios';
import './App.css';

function App() {
const [track, setTrack] = useState(0);
const [days, setDays] = useState(0);
const [newTrackName, setNewTrackName] = useState("");


const [tracklist,settracklist]  = useState([])
useEffect(()  =>  {
Axios.get("http://localhost:5000/read").then((response) =>  {
  settracklist(response.data);
});
},  []);
const submit  = ()  =>  {
  // console.log(track + days);
 Axios.post("http://localhost:5000/insert", {
   track: track,
    days: days,
 });
};

const updateTrack = (id)  =>  {
  Axios.put("http://localhost:5000/update", {id:  id, newTrackName: newTrackName});
};

const deleteTrack = (id)  =>  {
  Axios.delete(`http://localhost:5000/delete/${id}`);
};
  return (
    <div className="App">

     <h1> Tracker Sys </h1>
     <label>Number of Hours you Studied: </label>
     <input type="number"
     value={track}
     onChange={(event) => {
       setTrack(event.target.value);
     }} />

     <label>Number of Days: </label>
     <input type="number"
     value={days}
      onChange={(event) => {
        setDays(event.target.value);
      }} />
     <button onClick={submit}>Submit your track </button>

      <h2> Your Track List </h2>
      {tracklist.map((val,key) =>  {
        return ( <div key={key} className='track'>
          <label> Number of Hours you Studied </label>
          <input type="text" value={val.no_of_hours} />
          <hr></hr>
          {/* <h4> {val.no_of_hours} </h4> */}
          <label> Number of Days you Studied </label>
          <input type="number" value={val.days_cycle} />
        
          {/* <h4> {val.days_cycle} </h4> */}
          <input type="text" placeholder="Keep your track..."  onChange={(event) => {
       setNewTrackName(event.target.value);
     }} />
          <button onClick={() =>  updateTrack(val._id)}>Update</button>
          <button onClick={() => deleteTrack(val._id)}> Delete</button>
          </div>
        );
      })}
    </div>
  );
}

export default App;
